export { default as Navbar } from './Navbar/Navbar';
export { default as Footer } from './Footer/Footer';
export { default as InfoSection } from './InfoSection/InfoSection';
export { default as Pricing } from './Pricing/Pricing';
