export const homeObjOne = {
  primary: true,
  lightBg: false,
  lightTopLine: true,
  lightText: true,
  lightTextDesc: true,
  headline: 'With us, unleash the explorer within.',
  description:
    'Lets go beyond the constrain of the syllabus.',
  buttonLabel: 'FIND YOUR CALLING',
  imgStart: '',
  img: require('../../images/svg-1.svg'),
  alt: 'Image 1',
  start: ''
};

export const homeObjTwo = {
  primary: true,
  lightBg: false,
  lightTopLine: true,
  lightText: true,
  lightTextDesc: true,
  headline: 'OUR ACHIEVEMENTS',
  description:
    "ABC, XYZ, LMN",
  buttonLabel: 'Learn More',
  imgStart: '',
  img: require('../../images/svg-2.svg'),
  alt: 'Vault',
  start: ''
};

export const homeObjThree = {
  primary: false,
  lightBg: true,
  lightTopLine: false,
  lightText: false,
  lightTextDesc: false,
  headline:
    'OUR VISION',
  description:
    "Let's go beyond the constrain ofthe syllabus. EFDCMGMHFFGXFDFZDXBV BVCBVCVBCVCCG BFF",
  buttonLabel: 'Courses',
  imgStart: 'start',
  img: require('../../images/profile.jpg'),
  alt: 'Vault',
  start: 'true'
};

export const homeObjFour = {
  primary: true,
  lightBg: false,
  lightTopLine: true,
  lightText: true,
  lightTextDesc: true,
  headline: 'Blogs',
  buttonLabel: 'Go to Blogs',
  imgStart: 'start',
  img: require('../../images/svg-3.svg'),
  alt: 'Vault',
  start: 'true'
};
